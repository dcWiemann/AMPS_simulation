# Analysis and Simulation of Power Systems

**amps** is a lightweight and extensible circuit simulation tool written in Python.  

## License
MIT License. See `LICENSE` file for details.